"""
FitBuddy route handlers.
"""
import os
from fastapi import APIRouter, Request, Form, Depends
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.database import (
    get_db, save_user, save_plan, update_plan, get_user,
    get_original_plan, get_all_users, get_all_plans,
)
from app.gemini_generator import generate_workout_gemini
from app.gemini_flash_generator import generate_nutrition_tip_with_flash
from app.updated_plan import update_workout_plan

router = APIRouter()
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))


@router.get("/")
def home(request: Request):
    return templates.TemplateResponse(request=request, name="index.html", context={"request": request})


@router.post("/generate-workout")
def generate_workout(
    request: Request,
    username: str = Form(...),
    user_id: str = Form(...),
    age: int = Form(...),
    weight: float = Form(...),
    height: float = Form(...),
    gender: str = Form(...),
    goal: str = Form(...),
    activity_level: str = Form(...),
    intensity: str = Form(...),
    equipment: str = Form(...),
    workout_days: int = Form(...),
    db: Session = Depends(get_db),
):
    if age <= 0 or weight <= 0 or height <= 0:
        return templates.TemplateResponse(
            request=request, name="index.html",
            context={"request": request, "error": "Please enter positive values for age, weight and height."},
            status_code=400,
        )

    workout_plan = generate_workout_gemini(
        username, age, weight, goal, intensity,
        height=height, gender=gender, activity_level=activity_level,
        equipment=equipment, workout_days=workout_days
    )
    nutrition_tip = generate_nutrition_tip_with_flash(goal)

    save_user(db, user_id.strip(), username.strip(), age, weight, goal, intensity)
    save_plan(db, user_id.strip(), workout_plan, nutrition_tip)

    return templates.TemplateResponse(
        request=request, name="result.html", context={
            "request": request, "username": username, "user_id": user_id,
            "age": age, "weight": weight, "height": height, "gender": gender,
            "goal": goal, "activity_level": activity_level, "intensity": intensity,
            "equipment": equipment, "workout_days": workout_days,
            "workout_plan": workout_plan, "nutrition_tip": nutrition_tip,
            "updated_plan": None, "feedback_confirmation": None,
        },
    )


@router.post("/submit-feedback")
def submit_feedback(
    request: Request,
    user_id: str = Form(...),
    feedback: str = Form(...),
    db: Session = Depends(get_db),
):
    user_id = user_id.strip()
    feedback = feedback.strip()
    user = get_user(db, user_id)
    original = get_original_plan(db, user_id)

    if not user or not original:
        return templates.TemplateResponse(
            request=request, name="result.html", context={
                "request": request, "username": "Unknown", "user_id": user_id,
                "age": "-", "weight": "-", "goal": "-", "intensity": "-",
                "workout_plan": "No existing plan found for this User ID. Please generate a plan first.",
                "nutrition_tip": "", "updated_plan": None,
                "feedback_confirmation": None,
            },
            status_code=404,
        )

    revised_plan = update_workout_plan(original, feedback)
    nutrition_tip = generate_nutrition_tip_with_flash(user.goal)
    update_plan(db, user_id, revised_plan, nutrition_tip)

    return templates.TemplateResponse(
        request=request, name="result.html", context={
            "request": request, "username": user.username, "user_id": user.user_id,
            "age": user.age, "weight": user.weight, "goal": user.goal,
            "intensity": user.intensity, "workout_plan": original,
            "nutrition_tip": nutrition_tip, "updated_plan": revised_plan,
            "feedback_confirmation": "Your plan has been updated based on your feedback.",
        },
    )


@router.get("/view-all-users")
def view_all_users(request: Request, db: Session = Depends(get_db)):
    users = get_all_users(db)
    plans = get_all_plans(db)
    plans_by_user_id = {plan.user_id: plan for plan in plans}
    rows = [
        {
            "user": user,
            "original_plan": (plans_by_user_id.get(user.user_id).original_plan
                              if plans_by_user_id.get(user.user_id) else None),
            "updated_plan": (plans_by_user_id.get(user.user_id).updated_plan
                             if plans_by_user_id.get(user.user_id) else None),
            "nutrition_tip": (plans_by_user_id.get(user.user_id).nutrition_tip
                              if plans_by_user_id.get(user.user_id) else None),
        }
        for user in users
    ]
    return templates.TemplateResponse(request=request, name="all_users.html", context={"request": request, "rows": rows})


@router.get("/health")
def health():
    return {"status": "ok", "service": "fitbuddy"}
