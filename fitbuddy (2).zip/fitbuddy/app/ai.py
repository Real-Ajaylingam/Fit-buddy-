import json
from datetime import datetime
from app.config import GEMINI_API_KEY, GEMINI_MODEL

try:
    from google import genai
except Exception:
    genai = None

def generate_plan(profile: dict):
    """Generate a structured plan with Gemini. Falls back only when API is not configured."""
    if not GEMINI_API_KEY or genai is None:
        return demo_plan(profile)

    client = genai.Client(api_key=GEMINI_API_KEY)
    prompt = f"""
You are FitBuddy, a fitness planning assistant.
Create a practical 7-day beginner-to-intermediate fitness and nutrition plan from this profile:
{json.dumps(profile, indent=2)}

Return ONLY valid JSON with this exact shape:
{{
  "summary": "short personalized summary",
  "weekly_goal": "one sentence",
  "days": [
    {{
      "day": "Monday",
      "focus": "string",
      "duration_min": 45,
      "warmup": ["..."],
      "exercises": [{{"name":"...", "sets":3, "reps":"10", "rest_sec":60}}],
      "cooldown": ["..."],
      "meals": {{
        "breakfast":"...",
        "lunch":"...",
        "snack":"...",
        "dinner":"..."
      }}
    }}
  ],
  "tips": ["...","..."]
}}
Exactly 7 days. Avoid medical diagnosis. Include a safety note when appropriate.
"""
    response = client.models.generate_content(
        model=GEMINI_MODEL,
        contents=prompt,
        config={"response_mime_type": "application/json"},
    )
    return json.loads(response.text)

def revise_plan(old_plan: dict, feedback: dict):
    if not GEMINI_API_KEY or genai is None:
        return old_plan
    client = genai.Client(api_key=GEMINI_API_KEY)
    prompt = f"""
Revise this fitness plan using the user's feedback.
OLD PLAN:
{json.dumps(old_plan)}
FEEDBACK:
{json.dumps(feedback)}
Return ONLY valid JSON using the same schema as the old plan. Keep useful parts,
change exercises/volume/nutrition only where justified, and prioritize safety.
"""
    response = client.models.generate_content(
        model=GEMINI_MODEL,
        contents=prompt,
        config={"response_mime_type": "application/json"},
    )
    return json.loads(response.text)

def demo_plan(profile):
    goal = profile.get("goal", "General Fitness")
    days = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
    return {
        "summary": f"Starter plan focused on {goal}. Connect Gemini to generate a fully personalized AI plan.",
        "weekly_goal": "Build consistency with safe, progressive movement.",
        "days": [
            {"day": d, "focus": "Full Body" if i % 2 == 0 else "Recovery & Mobility",
             "duration_min": 35 if i % 2 == 0 else 20,
             "warmup": ["5 min easy walk", "Dynamic mobility"],
             "exercises": [{"name":"Bodyweight Squat","sets":3,"reps":"10","rest_sec":60},
                           {"name":"Incline Push-up","sets":3,"reps":"8","rest_sec":60}],
             "cooldown": ["Gentle stretching"],
             "meals": {"breakfast":"Oats + fruit + protein source",
                       "lunch":"Rice/roti + vegetables + protein",
                       "snack":"Fruit + nuts",
                       "dinner":"Vegetables + protein + whole grain"}} for i, d in enumerate(days)
        ],
        "tips": ["Hydrate regularly.", "Sleep consistently.", "Progress gradually."]
    }
