"""
Fast Gemini call for concise recovery/nutrition guidance.
"""
import os
try:
    from google import genai
except ImportError:  # optional until AI features are used
    genai = None

GOOGLE_API_KEY = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
GEMINI_FLASH_MODEL = os.getenv("GEMINI_FLASH_MODEL", "gemini-2.5-flash")

_client = genai.Client(api_key=GOOGLE_API_KEY) if (genai and GOOGLE_API_KEY) else None


def generate_nutrition_tip_with_flash(goal: str) -> str:
    prompt = (
        f"Give one concise, practical nutrition or recovery tip (2-3 sentences max) "
        f"for someone whose fitness goal is '{goal}'. Be specific and actionable. "
        "Plain text only. Avoid medical diagnosis or treatment advice."
    )

    if not _client:
        return _fallback_tip(goal)

    try:
        response = _client.models.generate_content(
            model=GEMINI_FLASH_MODEL,
            contents=prompt
        )
        return (response.text or "").strip() or _fallback_tip(goal)
    except Exception:
        return _fallback_tip(goal)


def _fallback_tip(goal: str) -> str:
    tips = {
        "weight loss": "Prioritize protein and fiber at meals, stay hydrated, and aim for gradual, sustainable changes rather than extreme restriction.",
        "muscle gain": "Include a protein-rich meal or snack around training and pair it with enough carbohydrates to support your activity.",
        "general wellness": "Stay hydrated, include a variety of vegetables and whole foods, and give your body enough sleep and recovery time.",
        "flexibility": "Stay hydrated and pair regular mobility work with gentle recovery sessions rather than forcing painful ranges of motion.",
    }
    return tips.get(goal.lower(), "Build balanced meals around protein, vegetables or fruit, whole-food carbohydrates, and healthy fats.")
