"""
Gemini-powered 7-day workout plan generation.
"""
import os
try:
    from google import genai
except ImportError:  # optional until AI features are used
    genai = None

GOOGLE_API_KEY = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
GEMINI_PRO_MODEL = os.getenv("GEMINI_MODEL") or os.getenv("GEMINI_PRO_MODEL", "gemini-2.5-flash")
_client = genai.Client(api_key=GOOGLE_API_KEY) if (genai and GOOGLE_API_KEY) else None


def _build_prompt(username: str, age: int, weight: float, goal: str, intensity: str,
                  height: float | None = None, gender: str = "prefer not to say",
                  activity_level: str = "moderate", equipment: str = "bodyweight",
                  workout_days: int = 5) -> str:
    return f"""
Create a realistic, beginner-friendly 7-day fitness plan.

Person:
- Name: {username}
- Age: {age}
- Weight: {weight} kg
- Height: {height if height else "not provided"} cm
- Gender: {gender}
- Goal: {goal}
- Current activity level: {activity_level}
- Preferred intensity: {intensity}
- Available equipment: {equipment}
- Preferred training days: {workout_days} days/week

Return exactly this structure for every day:
Day 1 - <focus>
  Warm-up: <5-10 min>
  Main workout: <exercise 1; exercise 2; exercise 3 with sets/reps or duration>
  Cooldown: <brief recovery>

Repeat through Day 7. Include at least one rest or active-recovery day.
Match exercise difficulty to the requested intensity. Keep instructions concise.
Plain text only; no markdown symbols or bullet characters.
Do not provide medical diagnosis or claim the plan is medically prescribed.
""".strip()


def generate_workout_gemini(username: str, age: int, weight: float, goal: str, intensity: str,
                             height: float | None = None, gender: str = "prefer not to say",
                             activity_level: str = "moderate", equipment: str = "bodyweight",
                             workout_days: int = 5) -> str:
    prompt = _build_prompt(username, age, weight, goal, intensity,
                           height, gender, activity_level, equipment, workout_days)

    if not _client:
        return _fallback_plan(goal, intensity)

    try:
        response = _client.models.generate_content(
            model=GEMINI_PRO_MODEL,
            contents=prompt
        )
        return (response.text or "").strip() or _fallback_plan(goal, intensity)
    except Exception:
        return _fallback_plan(goal, intensity)


def _fallback_plan(goal: str, intensity: str) -> str:
    days = [
        "Full Body", "Upper Body", "Cardio", "Lower Body",
        "Core & Mobility", "Active Recovery", "Rest"
    ]
    lines = [f"7-Day Plan — Goal: {goal}, Intensity: {intensity}", ""]
    for i, focus in enumerate(days, start=1):
        lines.extend([
            f"Day {i} - {focus}",
            "  Warm-up: 5-10 min light cardio and dynamic stretching",
            "  Main workout: 3-4 controlled exercises, 3 sets x 10-12 reps",
            "  Cooldown: 5 min easy movement and gentle stretching",
            ""
        ])
    return "\n".join(lines)
