import json
from pathlib import Path
import firebase_admin
from firebase_admin import credentials, db
from app.config import FIREBASE_DATABASE_URL, FIREBASE_SERVICE_ACCOUNT

_initialized = False

def init_firebase():
    global _initialized
    if _initialized:
        return True
    if not FIREBASE_DATABASE_URL:
        return False
    key_path = Path(FIREBASE_SERVICE_ACCOUNT)
    if not key_path.exists():
        return False
    try:
        cred = credentials.Certificate(str(key_path))
        firebase_admin.initialize_app(cred, {"databaseURL": FIREBASE_DATABASE_URL})
        _initialized = True
        return True
    except ValueError:
        _initialized = True
        return True
    except Exception:
        return False

def firebase_ready():
    return init_firebase()

def ref(path: str):
    if not init_firebase():
        raise RuntimeError("Firebase is not configured. Add service account JSON and FIREBASE_DATABASE_URL to .env")
    return db.reference(path)

def push(path: str, data: dict):
    key = ref(path).push().key
    ref(f"{path}/{key}").set(data)
    return key

def set_data(path: str, data):
    ref(path).set(data)

def get_data(path: str):
    return ref(path).get()
