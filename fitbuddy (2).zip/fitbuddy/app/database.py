"""
SQLite persistence layer for FitBuddy.
"""
from sqlalchemy import create_engine, Column, Integer, String, Text, Float, ForeignKey
from pathlib import Path
from sqlalchemy.orm import declarative_base, sessionmaker, relationship

BASE_DIR = Path(__file__).resolve().parent.parent
DATABASE_URL = f"sqlite:///{BASE_DIR / 'fitbuddy.db'}"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(String(40), unique=True, index=True, nullable=False)
    username = Column(String(80), nullable=False)
    age = Column(Integer, nullable=False)
    weight = Column(Float, nullable=False)
    goal = Column(String(40), nullable=False)
    intensity = Column(String(20), nullable=False)

    plan = relationship(
        "Plan", back_populates="user", uselist=False,
        cascade="all, delete-orphan"
    )


class Plan(Base):
    __tablename__ = "plans"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(String(40), ForeignKey("users.user_id"), unique=True, nullable=False)
    original_plan = Column(Text, nullable=True)
    updated_plan = Column(Text, nullable=True)
    nutrition_tip = Column(Text, nullable=True)

    user = relationship("User", back_populates="plan")


def init_db():
    Base.metadata.create_all(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def save_user(db, user_id: str, username: str, age: int, weight: float, goal: str, intensity: str) -> User:
    existing = db.query(User).filter(User.user_id == user_id).first()
    if existing:
        existing.username = username
        existing.age = age
        existing.weight = weight
        existing.goal = goal
        existing.intensity = intensity
        db.commit()
        db.refresh(existing)
        return existing

    user = User(
        user_id=user_id, username=username, age=age, weight=weight,
        goal=goal, intensity=intensity
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def get_user(db, user_id: str) -> User | None:
    return db.query(User).filter(User.user_id == user_id).first()


def save_plan(db, user_id: str, original_plan: str, nutrition_tip: str) -> Plan:
    existing = db.query(Plan).filter(Plan.user_id == user_id).first()
    if existing:
        existing.original_plan = original_plan
        existing.nutrition_tip = nutrition_tip
        existing.updated_plan = None
        db.commit()
        db.refresh(existing)
        return existing

    plan = Plan(
        user_id=user_id,
        original_plan=original_plan,
        nutrition_tip=nutrition_tip
    )
    db.add(plan)
    db.commit()
    db.refresh(plan)
    return plan


def get_original_plan(db, user_id: str) -> str | None:
    plan = db.query(Plan).filter(Plan.user_id == user_id).first()
    return plan.original_plan if plan else None


def update_plan(db, user_id: str, updated_plan_text: str, nutrition_tip: str | None = None) -> Plan | None:
    plan = db.query(Plan).filter(Plan.user_id == user_id).first()
    if not plan:
        return None
    plan.updated_plan = updated_plan_text
    if nutrition_tip:
        plan.nutrition_tip = nutrition_tip
    db.commit()
    db.refresh(plan)
    return plan


def get_all_users(db) -> list[User]:
    return db.query(User).order_by(User.id.desc()).all()


def get_all_plans(db) -> list[Plan]:
    return db.query(Plan).all()
